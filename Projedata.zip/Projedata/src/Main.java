import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
public class Main {
    public static void main(String[] args) {
        List<Funcionario> funcionarios = new ArrayList<>();
        funcionarios.add(new Funcionario("Maria", LocalDate.of(2000, Month.OCTOBER, 18), new BigDecimal("2009.44"), "OPERADOR"));
        funcionarios.add(new Funcionario("João", LocalDate.of(1990, Month.MAY, 12), new BigDecimal("2284.38"), "OPERADOR"));
        funcionarios.add(new Funcionario("Caio", LocalDate.of(1961, Month.MAY,02), new BigDecimal("9836.14"), "COORDENADOR"));
        funcionarios.add(new Funcionario("Miguel", LocalDate.of(1988, Month.OCTOBER,14), new BigDecimal("19119.88"), "DIRETOR"));
        funcionarios.add(new Funcionario("Alice", LocalDate.of(1995, Month.JANUARY,05), new BigDecimal("2234.68"), "RECEPCIONISTA"));
        funcionarios.add(new Funcionario("Heitor", LocalDate.of(1999, Month.NOVEMBER,19), new BigDecimal("1582.72"), "OPERADOR"));
        funcionarios.add(new Funcionario("Arthur", LocalDate.of(1993, Month.MARCH,31), new BigDecimal("4071.84"), "CONTADOR"));
        funcionarios.add(new Funcionario("Laura", LocalDate.of(1994, Month.JULY,8), new BigDecimal("3017.45"), "GERENTE"));
        funcionarios.add(new Funcionario("Heloisa", LocalDate.of(2003, Month.MAY,24), new BigDecimal("1606.85"), "ELETRICISTA"));
        funcionarios.add(new Funcionario("Helena", LocalDate.of(1996, Month.SEPTEMBER,2), new BigDecimal("2799.93"), "GERENTE"));


        // Remover o funcionário "João" da lista de pessoas
        funcionarios.removeIf(funcionario -> funcionario.getNome().equals("João"));

        // Imprimir todos os funcionários com todas suas informações
        System.out.println("Funcionários:");
        funcionarios.forEach(System.out::println);
        System.out.println();

        // Os funcionários receberam 10% de aumento de salário, atualizar a lista de funcionários com novo valor
        funcionarios.replaceAll(funcionario -> new Funcionario(funcionario.getNome(), funcionario.getDataNascimento(),
                funcionario.getSalarioComAumento(), funcionario.getFuncao()));

        // Agrupar os funcionários pela função MAP, com a chave "função" e o valor da "lista de funcionários"
        Map<String, List<Funcionario>> funcionariosPorFuncao = new HashMap<>();
        for (Funcionario funcionario : funcionarios) {
            String funcao = funcionario.getFuncao();
            if (funcionariosPorFuncao.containsKey(funcao)) {
                funcionariosPorFuncao.get(funcao).add(funcionario);
            } else {
                List<Funcionario> listaFuncionarios = new ArrayList<>();
                listaFuncionarios.add(funcionario);
                funcionariosPorFuncao.put(funcao, listaFuncionarios);
            }
        }

        // Imprimir os funcionários, agrupados por função
        System.out.println("Funcionários agrupados por função:");
        for (Map.Entry<String, List<Funcionario>> entry : funcionariosPorFuncao.entrySet()) {
            System.out.println(entry.getKey() + ":");
            entry.getValue().forEach(System.out::println);
            System.out.println();
        }

        // Imprimir os funcionários que fazem aniversário no mês 10 e 12
        System.out.println("Funcionários que fazem aniversário no mês 10 e 12:");
        DateTimeFormatter formatterMes = DateTimeFormatter.ofPattern("MM");
        for (Funcionario funcionario : funcionarios) {
            String mesNascimento = formatterMes.format(funcionario.getDataNascimento());
            if (mesNascimento.equals("10") || mesNascimento.equals("12")) {
                System.out.println(funcionario);
            }
        }
        System.out.println();

        // Imprimir o funcionário com a maior idade
        Funcionario funcionarioMaisVelho = Collections.max(funcionarios, (f1, f2) -> f1.getIdade() - f2.getIdade());
        System.out.println("Funcionário mais velho:");
        System.out.println("Nome: " + funcionarioMaisVelho.getNome() + " | Idade: " + funcionarioMaisVelho.getIdade());
        System.out.println();

        // Imprimir a lista de funcionários por ordem alfabética
        System.out.println("Funcionários em ordem alfabética:");
        Collections.sort(funcionarios, (f1, f2) -> f1.getNome().compareTo(f2.getNome()));
        funcionarios.forEach(System.out::println);
        System.out.println();

        // Imprimir o total dos salários dos funcionários
        BigDecimal totalSalarios = BigDecimal.ZERO;
        for (Funcionario funcionario : funcionarios) {
            totalSalarios = totalSalarios.add(funcionario.getSalario());
        }
        System.out.println("Total dos salários: " + String.format("%.2f", totalSalarios).replace(".", ","));
        System.out.println();

        // Imprimir quantos salários mínimos ganha cada funcionário
        System.out.println("Quantidade de salários mínimos por funcionário:");
        for (Funcionario funcionario : funcionarios) {
            System.out.println(funcionario.getNome() + ": " + funcionario.getQuantidadeSalariosMinimos());
        }
    }
}


