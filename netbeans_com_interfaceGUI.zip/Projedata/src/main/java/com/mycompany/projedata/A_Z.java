package com.mycompany.projedata;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javax.swing.table.DefaultTableModel;
public class A_Z extends javax.swing.JFrame {

    

public class FuncionarioComparator implements Comparator<Funcionario> {
    @Override
    public int compare(Funcionario f1, Funcionario f2) {
        return f1.getNome().compareTo(f2.getNome());
    }
}
    public A_Z() {
        initComponents();
        List<Funcionario> funcionarios = new ArrayList<>();
        funcionarios.add(new Funcionario("Maria", LocalDate.of(2000, Month.OCTOBER, 18), new BigDecimal("2009.44"), "OPERADOR"));
        funcionarios.add(new Funcionario("João", LocalDate.of(1990, Month.MAY, 12), new BigDecimal("2284.38"), "OPERADOR"));
        funcionarios.add(new Funcionario("Caio", LocalDate.of(1961, Month.MAY,02), new BigDecimal("9836.14"), "COORDENADOR"));
        funcionarios.add(new Funcionario("Miguel", LocalDate.of(1988, Month.OCTOBER,14), new BigDecimal("19119.88"), "DIRETOR"));
        funcionarios.add(new Funcionario("Alice", LocalDate.of(1995, Month.JANUARY,05), new BigDecimal("2234.68"), "RECEPCIONISTA"));
        funcionarios.add(new Funcionario("Heitor", LocalDate.of(1999, Month.NOVEMBER,19), new BigDecimal("1582.72"), "OPERADOR"));
        funcionarios.add(new Funcionario("Arthur", LocalDate.of(1993, Month.MARCH,31), new BigDecimal("4071.84"), "CONTADOR"));
        funcionarios.add(new Funcionario("Laura", LocalDate.of(1994, Month.JULY,8), new BigDecimal("3017.45"), "GERENTE"));
        funcionarios.add(new Funcionario("Heloisa", LocalDate.of(2003, Month.MAY,24), new BigDecimal("1606.85"), "ELETRICISTA"));
        funcionarios.add(new Funcionario("Helena", LocalDate.of(1996, Month.SEPTEMBER,2), new BigDecimal("2799.93"), "GERENTE"));
Collections.sort(funcionarios, new FuncionarioComparator());
DefaultTableModel modelo = new DefaultTableModel(new String[]{"Nome", "Data Nasc.", "Salário", "Função"}, 0);
        for (Funcionario funcionario : funcionarios) {
            modelo.addRow(new String[] {funcionario.getNome(), funcionario.getDataNascimentoFormatada(), funcionario.getSalarioFormatado(), funcionario.getFuncao()});

        }
        tabela.setModel(modelo);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tabela = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        tabela.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        tabela.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "c", "cc", "cccc", "nullcc"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tabela);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 668, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 380, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new A_Z().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabela;
    // End of variables declaration//GEN-END:variables
}
