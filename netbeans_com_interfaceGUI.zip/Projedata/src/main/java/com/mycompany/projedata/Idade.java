package com.mycompany.projedata;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Idade extends javax.swing.JFrame {

    public Idade() {
        initComponents();
        List<Funcionario> funcionarios = new ArrayList<>();
        funcionarios.add(new Funcionario("Maria", LocalDate.of(2000, Month.OCTOBER, 18), new BigDecimal("2009.44"), "OPERADOR"));
        funcionarios.add(new Funcionario("João", LocalDate.of(1990, Month.MAY, 12), new BigDecimal("2284.38"), "OPERADOR"));
        funcionarios.add(new Funcionario("Caio", LocalDate.of(1961, Month.MAY,02), new BigDecimal("9836.14"), "COORDENADOR"));
        funcionarios.add(new Funcionario("Miguel", LocalDate.of(1988, Month.OCTOBER,14), new BigDecimal("19119.88"), "DIRETOR"));
        funcionarios.add(new Funcionario("Alice", LocalDate.of(1995, Month.JANUARY,05), new BigDecimal("2234.68"), "RECEPCIONISTA"));
        funcionarios.add(new Funcionario("Heitor", LocalDate.of(1999, Month.NOVEMBER,19), new BigDecimal("1582.72"), "OPERADOR"));
        funcionarios.add(new Funcionario("Arthur", LocalDate.of(1993, Month.MARCH,31), new BigDecimal("4071.84"), "CONTADOR"));
        funcionarios.add(new Funcionario("Laura", LocalDate.of(1994, Month.JULY,8), new BigDecimal("3017.45"), "GERENTE"));
        funcionarios.add(new Funcionario("Heloisa", LocalDate.of(2003, Month.MAY,24), new BigDecimal("1606.85"), "ELETRICISTA"));
        funcionarios.add(new Funcionario("Helena", LocalDate.of(1996, Month.SEPTEMBER,2), new BigDecimal("2799.93"), "GERENTE"));
        Funcionario funcionarioMaisVelho = Collections.max(funcionarios, (f1, f2) -> f1.getIdade() - f2.getIdade());
        lbnNome.setText(funcionarioMaisVelho.getNome());
        lbnIdade.setText(String.valueOf(funcionarioMaisVelho.getIdade()));
    
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lbntxt = new javax.swing.JLabel();
        lbnNome = new javax.swing.JLabel();
        lbntxt2 = new javax.swing.JLabel();
        lbnIdade = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        lbntxt.setFont(new java.awt.Font("Times New Roman", 1, 22)); // NOI18N
        lbntxt.setText("Funcionario mais velho:");

        lbnNome.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N

        lbntxt2.setFont(new java.awt.Font("Times New Roman", 1, 22)); // NOI18N
        lbntxt2.setText("Idade:");

        lbnIdade.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbntxt)
                    .addComponent(lbnNome, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 17, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbnIdade, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(lbntxt2)))
                .addGap(20, 20, 20))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbntxt)
                    .addComponent(lbntxt2))
                .addGap(73, 73, 73)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbnNome, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbnIdade, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(24, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Idade().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel lbnIdade;
    private javax.swing.JLabel lbnNome;
    private javax.swing.JLabel lbntxt;
    private javax.swing.JLabel lbntxt2;
    // End of variables declaration//GEN-END:variables
}
