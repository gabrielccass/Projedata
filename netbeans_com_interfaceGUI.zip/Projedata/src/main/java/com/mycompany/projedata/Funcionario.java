package com.mycompany.projedata;
import java.math.BigDecimal;
import java.time.LocalDate;
public class Funcionario extends Pessoa {
    private BigDecimal salario;
    private String funcao;

    public Funcionario(String nome, LocalDate dataNascimento, BigDecimal salario, String funcao) {
        super(nome, dataNascimento);
        this.salario = salario;
        this.funcao = funcao;
    }

    public BigDecimal getSalario() {
        return salario;
    }

    public String getFuncao() {
        return funcao;
    }

    public BigDecimal getSalarioComAumento() {
        return this.salario.multiply(new BigDecimal("1.1"));
    }

    public int getQuantidadeSalariosMinimos() {
        BigDecimal salarioMinimo = new BigDecimal("1212.00");
        return this.salario.divide(salarioMinimo, 0, BigDecimal.ROUND_DOWN).intValue();
    }

    public String getSalarioFormatado() {
        return String.format("%.2f", this.salario).replace(".", ",");
    }

    @Override
    public String toString() {
        return "Funcionario [nome: " + getNome() + ", dataNascimento: " + getDataNascimentoFormatada() + ", salario: "
                + getSalarioFormatado() + ", funcao: " + funcao + "]";
    }
}