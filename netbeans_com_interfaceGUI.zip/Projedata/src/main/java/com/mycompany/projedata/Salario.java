package com.mycompany.projedata;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;

public class Salario extends javax.swing.JFrame {

    public Salario() {
        initComponents();
         List<Funcionario> funcionarios = new ArrayList<>();
        funcionarios.add(new Funcionario("Maria", LocalDate.of(2000, Month.OCTOBER, 18), new BigDecimal("2009.44"), "OPERADOR"));
        funcionarios.add(new Funcionario("João", LocalDate.of(1990, Month.MAY, 12), new BigDecimal("2284.38"), "OPERADOR"));
        funcionarios.add(new Funcionario("Caio", LocalDate.of(1961, Month.MAY,02), new BigDecimal("9836.14"), "COORDENADOR"));
        funcionarios.add(new Funcionario("Miguel", LocalDate.of(1988, Month.OCTOBER,14), new BigDecimal("19119.88"), "DIRETOR"));
        funcionarios.add(new Funcionario("Alice", LocalDate.of(1995, Month.JANUARY,05), new BigDecimal("2234.68"), "RECEPCIONISTA"));
        funcionarios.add(new Funcionario("Heitor", LocalDate.of(1999, Month.NOVEMBER,19), new BigDecimal("1582.72"), "OPERADOR"));
        funcionarios.add(new Funcionario("Arthur", LocalDate.of(1993, Month.MARCH,31), new BigDecimal("4071.84"), "CONTADOR"));
        funcionarios.add(new Funcionario("Laura", LocalDate.of(1994, Month.JULY,8), new BigDecimal("3017.45"), "GERENTE"));
        funcionarios.add(new Funcionario("Heloisa", LocalDate.of(2003, Month.MAY,24), new BigDecimal("1606.85"), "ELETRICISTA"));
        funcionarios.add(new Funcionario("Helena", LocalDate.of(1996, Month.SEPTEMBER,2), new BigDecimal("2799.93"), "GERENTE"));

                BigDecimal totalSalarios = BigDecimal.ZERO;
        for (Funcionario funcionario : funcionarios) {
            totalSalarios = totalSalarios.add(funcionario.getSalario());
        }
        lbnSalario.setText(String.format("%.2f", totalSalarios).replace(".", ","));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lbntxt = new javax.swing.JLabel();
        lbnSalario = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        lbntxt.setFont(new java.awt.Font("Times New Roman", 1, 22)); // NOI18N
        lbntxt.setText("Total dos salarios:");

        lbnSalario.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(lbntxt)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 75, Short.MAX_VALUE)
                .addComponent(lbnSalario)
                .addGap(118, 118, 118))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(128, 128, 128)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbntxt)
                    .addComponent(lbnSalario))
                .addContainerGap(145, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Salario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel lbnSalario;
    private javax.swing.JLabel lbntxt;
    // End of variables declaration//GEN-END:variables
}
