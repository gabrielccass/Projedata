package com.mycompany.projedata;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
public class Tela extends javax.swing.JFrame {

    public Tela() {
        initComponents();
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jbtnRjoao = new javax.swing.JButton();
        jbtnFuncionarios = new javax.swing.JButton();
        jbtnAumento = new javax.swing.JButton();
        jbtnAgrupar = new javax.swing.JButton();
        jbtnIdade = new javax.swing.JButton();
        jbtnA_Z = new javax.swing.JButton();
        jbtnSalario = new javax.swing.JButton();
        jbtnTotal = new javax.swing.JButton();
        jbtnAnivesarios = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jbtnRjoao.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jbtnRjoao.setText("Remover João");
        jbtnRjoao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnRjoaoActionPerformed(evt);
            }
        });

        jbtnFuncionarios.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jbtnFuncionarios.setText("Funcionarios");
        jbtnFuncionarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnFuncionariosActionPerformed(evt);
            }
        });

        jbtnAumento.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jbtnAumento.setText("Aumento");
        jbtnAumento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAumentoActionPerformed(evt);
            }
        });

        jbtnAgrupar.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jbtnAgrupar.setText("Agrupar");
        jbtnAgrupar.setMaximumSize(new java.awt.Dimension(87, 23));
        jbtnAgrupar.setMinimumSize(new java.awt.Dimension(87, 23));
        jbtnAgrupar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAgruparActionPerformed(evt);
            }
        });

        jbtnIdade.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jbtnIdade.setText("Idade");
        jbtnIdade.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnIdadeActionPerformed(evt);
            }
        });

        jbtnA_Z.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jbtnA_Z.setText("A-Z");
        jbtnA_Z.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnA_ZActionPerformed(evt);
            }
        });

        jbtnSalario.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jbtnSalario.setText("Salario");
        jbtnSalario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnSalarioActionPerformed(evt);
            }
        });

        jbtnTotal.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jbtnTotal.setText("Total");
        jbtnTotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnTotalActionPerformed(evt);
            }
        });

        jbtnAnivesarios.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jbtnAnivesarios.setText("Aniversarios");
        jbtnAnivesarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnAnivesariosActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jbtnFuncionarios, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jbtnAgrupar, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jbtnAumento, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jbtnRjoao))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 125, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jbtnA_Z, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jbtnSalario, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jbtnTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jbtnIdade, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(43, 43, 43))
            .addGroup(layout.createSequentialGroup()
                .addGap(164, 164, 164)
                .addComponent(jbtnAnivesarios, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(68, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbtnRjoao, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jbtnIdade, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbtnFuncionarios, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jbtnA_Z, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbtnAumento, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jbtnSalario, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbtnAgrupar, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jbtnTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jbtnAnivesarios)
                .addGap(67, 67, 67))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jbtnRjoaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnRjoaoActionPerformed
        RJoao rjoao = new RJoao();
                rjoao.setVisible(true);
    }//GEN-LAST:event_jbtnRjoaoActionPerformed

    private void jbtnFuncionariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnFuncionariosActionPerformed
        Funcionarios funcionarios = new Funcionarios();
        funcionarios.setVisible(true);
    }//GEN-LAST:event_jbtnFuncionariosActionPerformed

    private void jbtnAnivesariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAnivesariosActionPerformed
        Aniversario aniversario = new Aniversario();
        aniversario.setVisible(true);
    }//GEN-LAST:event_jbtnAnivesariosActionPerformed

    private void jbtnAumentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAumentoActionPerformed
         Aumento aumento = new Aumento();
         aumento.setVisible(true);
    }//GEN-LAST:event_jbtnAumentoActionPerformed

    private void jbtnAgruparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnAgruparActionPerformed
        Agrupar agrupar = new Agrupar();
        agrupar.setVisible(true);
    }//GEN-LAST:event_jbtnAgruparActionPerformed

    private void jbtnIdadeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnIdadeActionPerformed
        Idade idade = new Idade();
        idade.setVisible(true);
    }//GEN-LAST:event_jbtnIdadeActionPerformed

    private void jbtnSalarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnSalarioActionPerformed
        Salario salario = new Salario();
        salario.setVisible(true);
    }//GEN-LAST:event_jbtnSalarioActionPerformed

    private void jbtnTotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnTotalActionPerformed
        Total total = new Total();
        total.setVisible(true);
    }//GEN-LAST:event_jbtnTotalActionPerformed

    private void jbtnA_ZActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnA_ZActionPerformed
       A_Z a_z = new A_Z();
       a_z.setVisible(true);
    }//GEN-LAST:event_jbtnA_ZActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Tela().setVisible(true);
            }
        });
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jbtnA_Z;
    private javax.swing.JButton jbtnAgrupar;
    private javax.swing.JButton jbtnAnivesarios;
    private javax.swing.JButton jbtnAumento;
    private javax.swing.JButton jbtnFuncionarios;
    private javax.swing.JButton jbtnIdade;
    private javax.swing.JButton jbtnRjoao;
    private javax.swing.JButton jbtnSalario;
    private javax.swing.JButton jbtnTotal;
    // End of variables declaration//GEN-END:variables
}
